
var CANNON = require('cannon');
var world = new CANNON.World()
world.gravity.set(0, -9.8, 0)

//cube.position.y=2
var cubeBody = new CANNON.Body({
mass: 10,
position: new CANNON.Vec3(0, 2, 0)
})
var cubeShape = new CANNON.Box(new CANNON.Vec3(0.5,  0.5 , 0.5))
cubeBody.addShape(cubeShape)
world.addBody(cubeBody)


var plateBody = new CANNON.Body({
type: CANNON.Body.STATIC,
position: new CANNON.Vec3(0, 0, 0),
shape: new CANNON.Box(new CANNON.Vec3(2.5,  0.05 , 2.5))
})
world.addBody(plateBody)









setInterval(function(){
world.step(1 / 60)
console.log(cubeBody.position.y)
},1000/25)